/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


package com.mycompany.exam2024;

/**
 *
 * @author pelis
 */
public class Main {

    public static void main(String[] args) {

        // Single-dimensional array for movie names
        String[] movies = {
            "Napoleon",
            "Oppenheimer"
        };

        // Two-dimensional array for monthly ticket sales
        int[][] movieTicketSales = {
            {3000, 1500, 1700},
            {3500, 1200, 1600}
        };

        // Array to store total sales for each movie
        int[] totalSales = new int[movies.length];

        // Create MovieTickets object
        MovieTickets mt = new MovieTickets();

        // Display report heading
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println();

        System.out.printf("%-20s%10s%10s%10s%n",
                "", "JAN", "FEB", "MAR");

        System.out.println("-----------------------------------------------");

        // Display movie names and monthly sales
        for (int i = 0; i < movies.length; i++) {

            System.out.printf("%-20s%10d%10d%10d%n",
                    movies[i],
                    movieTicketSales[i][0],
                    movieTicketSales[i][1],
                    movieTicketSales[i][2]);

            // Calculate total sales for each movie
            totalSales[i] = 0;

            for (int j = 0; j < movieTicketSales[i].length; j++) {

                totalSales[i] += movieTicketSales[i][j];

            }
        }

        System.out.println();

        // Display total sales for each movie
        for (int i = 0; i < movies.length; i++) {

            System.out.println("Total movie ticket sales for "
                    + movies[i] + " " + totalSales[i]);
        }

        System.out.println();

        // Find top performing movie
        int highestSales = totalSales[0];
        int topMovieIndex = 0;

        for (int i = 1; i < totalSales.length; i++) {

            if (totalSales[i] > highestSales) {

                highestSales = totalSales[i];

                topMovieIndex = i;
            }
        }

        // Display top performing movie
        System.out.println("Top performing movie: "
                + movies[topMovieIndex]);
    }
}

    

