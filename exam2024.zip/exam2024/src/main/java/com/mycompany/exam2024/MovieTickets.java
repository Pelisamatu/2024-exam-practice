/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package com.mycompany.exam2024;

/**
 *
 * @author pelis
 */
public class MovieTickets implements IMovieTickets {

    private final double VAT_RATE = 0.14;

    // =====================================
    // QUESTION 1.2
    // Calculate total movie ticket sales
    // =====================================

    public int TotalMovieSales(int[] movieTicketSales) {

        int total = 0;

        for (int i = 0; i < movieTicketSales.length; i++) {

            total += movieTicketSales[i];
        }

        return total;
    }

    // =====================================
    // QUESTION 1.2
    // Find top performing movie
    // =====================================

    public String TopMovie(String[] movies, int[] totalSales) {

        int highest = totalSales[0];
        int index = 0;

        for (int i = 1; i < totalSales.length; i++) {

            if (totalSales[i] > highest) {

                highest = totalSales[i];
                index = i;
            }
        }

        return movies[index];
    }

    // =====================================
    // QUESTION 2.8
    // Calculate total ticket price
    // Including 14% VAT
    // =====================================

    @Override
    public double CalculateTotalTicketPrice(
            int numberOfTickets, double ticketPrice) {

        double subtotal = numberOfTickets * ticketPrice;

        double vat = subtotal * VAT_RATE;

        double total = subtotal + vat;

        return total;
    }

    // =====================================
    // QUESTION 2.8
    // Validate movie ticket information
    // =====================================

    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {

        // Check for null data
        if (movieTicketData == null) {

            return false;
        }

        // Validate movie name
        if (movieTicketData.getMovieName() == null ||
            movieTicketData.getMovieName().trim().isEmpty()) {

            return false;
        }

        // Validate ticket price
        double price = movieTicketData.getTicketPrice();

        if (price <= 0 ||
            Double.isNaN(price) ||
            Double.isInfinite(price)) {

            return false;
        }

        // Validate number of tickets
        if (movieTicketData.getNumberOfTickets() <= 0) {

            return false;
        }

        return true;
    }
}
