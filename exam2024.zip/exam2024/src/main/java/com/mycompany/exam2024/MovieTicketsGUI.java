/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exam2024;

/**
 *
 * @author pelis
*/
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;

public class MovieTicketsGUI extends JFrame {

    private JComboBox<String> cmbMovie;
    private JTextField txtNumberOfTickets;
    private JTextField txtTicketPrice;
    private JTextArea txtTicketReport;

    private MovieTickets movieTickets;

    public MovieTicketsGUI() {

        movieTickets = new MovieTickets();

        // Window settings
        setTitle("MOVIE TICKETS");
        setSize(450, 420);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");

        fileMenu.add(exitItem);
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        // Create form panel
        JPanel panel = new JPanel(new GridBagLayout());

        panel.setBorder(BorderFactory.createEmptyBorder(
                15, 15, 10, 15));

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(8, 5, 8, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Movie selection
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.4;

        panel.add(new JLabel("MOVIE:"), gbc);

        String[] movies = {
            "Napoleon",
            "Oppenheimer",
            "Dam"
        };

        cmbMovie = new JComboBox<>(movies);

        gbc.gridx = 1;
        gbc.weightx = 0.6;

        panel.add(cmbMovie, gbc);

        // Number of tickets
        gbc.gridx = 0;
        gbc.gridy = 1;

        panel.add(new JLabel("NUMBER OF TICKETS:"), gbc);

        txtNumberOfTickets = new JTextField();

        gbc.gridx = 1;

        panel.add(txtNumberOfTickets, gbc);

        // Ticket price
        gbc.gridx = 0;
        gbc.gridy = 2;

        panel.add(new JLabel("TICKET PRICE:"), gbc);

        txtTicketPrice = new JTextField();

        gbc.gridx = 1;

        panel.add(txtTicketPrice, gbc);

        // Report label
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;

        panel.add(new JLabel("TICKET REPORT:"), gbc);

        // Create report area
        txtTicketReport = new JTextArea(8, 30);

        txtTicketReport.setEditable(false);
        txtTicketReport.setLineWrap(true);
        txtTicketReport.setWrapStyleWord(true);

        txtTicketReport.setFont(
                new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scrollPane =
                new JScrollPane(txtTicketReport);

        // Main layout
        setLayout(new BorderLayout());

        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Q2.3: Exit application
        exitItem.addActionListener(e -> {
            System.exit(0);
        });

        // Q2.4 and Q2.5: Process tickets
        processItem.addActionListener(e -> {
            processTickets();
        });

        // Q2.6: Clear fields
        clearItem.addActionListener(e -> {
            clearFields();
        });
    }

    // Process movie tickets
    private void processTickets() {

        try {

            // Capture selected movie
            String movie =
                    (String) cmbMovie.getSelectedItem();

            // Capture number of tickets
            int numberOfTickets = Integer.parseInt(
                    txtNumberOfTickets.getText().trim());

            // Capture ticket price
            double ticketPrice = Double.parseDouble(
                    txtTicketPrice.getText().trim());

            // Create MovieTicketData object
            MovieTicketData movieTicketData =
                    new MovieTicketData(
                            movie,
                            ticketPrice,
                            numberOfTickets
                    );

            // Q2.8: Validate movie ticket information
            if (!movieTickets.ValidateData(movieTicketData)) {

                JOptionPane.showMessageDialog(this,
                        "Invalid movie ticket information!\n\n"
                        + "Movie name cannot be empty.\n"
                        + "Ticket price must be greater than zero.\n"
                        + "Number of tickets must be greater than zero.",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);

                return;
            }

            // Q2.8: Calculate total ticket price including VAT
            double total =
                    movieTickets.CalculateTotalTicketPrice(
                            numberOfTickets,
                            ticketPrice
                    );

            // Generate ticket report
            String report =
                    "MOVIE TICKET REPORT\n"
                    + "**************************************\n"
                    + "MOVIE NAME: " + movie + "\n"
                    + String.format(
                            "MOVIE TICKET PRICE: R %.1f%n",
                            ticketPrice)
                    + "NUMBER OF TICKETS: "
                    + numberOfTickets + "\n"
                    + String.format(
                            "TOTAL TICKET PRICE: R %.1f%n",
                            total)
                    + "**************************************";

            // Display report
            txtTicketReport.setText(report);

            // Q2.5: Save report to report.txt
            try {

                Files.write(
                        Paths.get("report.txt"),
                        report.getBytes(StandardCharsets.UTF_8)
                );

                JOptionPane.showMessageDialog(this,
                        "Report successfully saved as report.txt");

            } catch (IOException e) {

                JOptionPane.showMessageDialog(this,
                        "Error saving report: " + e.getMessage(),
                        "File Error",
                        JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(this,
                    "Please enter valid numbers for "
                    + "ticket price and number of tickets.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // Q2.6: Clear all fields
    private void clearFields() {

        cmbMovie.setSelectedIndex(0);

        txtNumberOfTickets.setText("");

        txtTicketPrice.setText("");

        txtTicketReport.setText("");

        txtNumberOfTickets.requestFocus();
    }

    // Main method
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            MovieTicketsGUI gui = new MovieTicketsGUI();

            gui.setVisible(true);

        });
    }
}

