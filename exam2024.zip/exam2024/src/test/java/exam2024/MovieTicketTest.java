/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author pelis
 */

package com.mycompany.exam2024;

import com.mycompany.exam2024.MovieTickets;
import com.mycompany.exam2024.MovieTicketData;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MovieTicketsTest {

    // Test 1: Calculate total ticket price successfully
    @Test
    public void CalculateTotalTicketPrice_CalculatedSuccessfully() {

        MovieTickets mt = new MovieTickets();

        int numberOfTickets = 3;
        double ticketPrice = 100.0;

        double expectedTotal = 342.0;

        double actualTotal = mt.CalculateTotalTicketPrice(
                numberOfTickets, ticketPrice);

        assertEquals(expectedTotal, actualTotal, 0.01);
    }

    // Test 2: Validate movie ticket information
    @Test
    public void ValidationTests() {

        MovieTickets mt = new MovieTickets();

        // Invalid ticket price (zero)
        MovieTicketData data = new MovieTicketData(
                "Napoleon", 0, 3);

        boolean result = mt.ValidateData(data);

        assertFalse(result);
    }
}
